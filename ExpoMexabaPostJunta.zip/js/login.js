var text = document.getElementById("password");
var textHidden = document.getElementById("passwordhidden");
var pass = "expo2021";