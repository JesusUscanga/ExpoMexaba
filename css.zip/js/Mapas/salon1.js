    const maxima = document.getElementById('openMaxima');
    const nestle = document.getElementById('openNestle');
    const laFina = document.getElementById('openLaFina');
    const sanMarcos = document.getElementById('openSanMarcos');
    const patrona = document.getElementById('openPatrona');
    const costena = document.getElementById('openCostena');
    const laItaliana = document.getElementById('openLaItaliana');
    const moderna = document.getElementById('openModerna');
    const laMorena = document.getElementById('openLaMorena');
    const clemente = document.getElementById('openClemente');
    const herdez = document.getElementById('openHerdez');
    const pinsa = document.getElementById('openPinsa');

    const popupMaxima = document.getElementById('popupMaxima');
    const popupNestle = document.getElementById('popupNestle');
    const popupLaFina = document.getElementById('popupLaFina');
    const popupSanMarcos = document.getElementById('popupSanMarcos');
    const popupPatrona = document.getElementById('popupPatrona');
    const popupCostena = document.getElementById('popupCostena');
    const popupLaItaliana = document.getElementById('popupLaItaliana');
    const popupModerna = document.getElementById('popupModerna');
    const popupLaMorena = document.getElementById('popupLaMorena');
    const popupClemente = document.getElementById('popupClemente');
    const popupHerdez = document.getElementById('popupHerdez');
    const popupPinsa = document.getElementById('popupPinsa');

    const closeMaxima = document.getElementById('closeMaxima');
    const closeNestle = document.getElementById('closeNestle');
    const closeLaFina = document.getElementById('closeLaFina');
    const closeSanMarcos = document.getElementById('closeSanMarcos');
    const closePatrona = document.getElementById('closePatrona');
    const closeCostena = document.getElementById('closeCostena');
    const closeLaItaliana = document.getElementById('closeLaItaliana');
    const closeModerna = document.getElementById('closeModerna');
    const closeLaMorena = document.getElementById('closeLaMorena');
    const closeClemente = document.getElementById('closeClemente');
    const closeHerdez = document.getElementById('closeHerdez');
    const closePinsa = document.getElementById('closePinsa');

    maxima.addEventListener('click', () => {
        popupMaxima.classList.add('show');
    });
    nestle.addEventListener('click', () => {
        popupNestle.classList.add('show');
    });
    laFina.addEventListener('click', () => {
        popupLaFina.classList.add('show');
    });
    sanMarcos.addEventListener('click', () => {
        popupSanMarcos.classList.add('show');
    });
    patrona.addEventListener('click', () => {
        popupPatrona.classList.add('show');
    });
    costena.addEventListener('click', () => {
        popupCostena.classList.add('show');
    });
    laItaliana.addEventListener('click', () => {
        popupLaItaliana.classList.add('show');
    });
    moderna.addEventListener('click', () => {
        popupModerna.classList.add('show');
    });
    laMorena.addEventListener('click', () => {
        popupLaMorena.classList.add('show');
    });
    clemente.addEventListener('click', () => {
        popupClemente.classList.add('show');
    });
    herdez.addEventListener('click', () => {
        popupHerdez.classList.add('show');
    });
    pinsa.addEventListener('click', () => {
        popupPinsa.classList.add('show');
    });


    closeMaxima.addEventListener('click', () => {
        popupMaxima.classList.remove('show');
    });
    closeNestle.addEventListener('click', () => {
        popupNestle.classList.remove('show');
    });
    closeLaFina.addEventListener('click', () => {
        popupLaFina.classList.remove('show');
    });
    closeSanMarcos.addEventListener('click', () => {
        popupSanMarcos.classList.remove('show');
    });
    closePatrona.addEventListener('click', () => {
        popupPatrona.classList.remove('show');
    });
    closeCostena.addEventListener('click', () => {
        popupCostena.classList.remove('show');
    });
    closeLaItaliana.addEventListener('click', () => {
        popupLaItaliana.classList.remove('show');
    });
    closeModerna.addEventListener('click', () => {
        popupModerna.classList.remove('show');
    });
    closeLaMorena.addEventListener('click', () => {
        popupLaMorena.classList.remove('show');
    });
    closeClemente.addEventListener('click', () => {
        popupClemente.classList.remove('show');
    });
    closeHerdez.addEventListener('click', () => {
        popupHerdez.classList.remove('show');
    });
    closePinsa.addEventListener('click', () => {
        popupPinsa.classList.remove('show');
    });