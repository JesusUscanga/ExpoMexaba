const pronto = document.getElementById('openPronto');
const selecta = document.getElementById('openSelecta');
const maseca = document.getElementById('openMaseca');
const pepsico = document.getElementById('openPepsico');
const cuetara = document.getElementById('openCuetara');
const nissin = document.getElementById('openNissin');
const alpura = document.getElementById('openAlpura');
const tamariz = document.getElementById('openTamariz');
const lala = document.getElementById('openLala');
const empacados = document.getElementById('openEmpacados');
const salchichoneria = document.getElementById('openSalchichoneria');
const qualamex = document.getElementById('openQualamex');

const popupPronto = document.getElementById('popupPronto');
const popupSelecta = document.getElementById('popupSelecta');
const popupMaseca = document.getElementById('popupMaseca');
const popupPepsico = document.getElementById('popupPepsico');
const popupCuetara = document.getElementById('popupCuetara');
const popupNissin = document.getElementById('popupNissin');
const popupAlpura = document.getElementById('popupAlpura');
const popupTamariz = document.getElementById('popupTamariz');
const popupLala = document.getElementById('popupLala');
const popupEmpacados = document.getElementById('popupEmpacados');
const popupSalchichoneria = document.getElementById('popupSalchichoneria');
const popupQualamex = document.getElementById('popupQualamex');

const closePronto = document.getElementById('closePronto');
const closeSelecta = document.getElementById('closeSelecta');
const closeMaseca = document.getElementById('closeMaseca');
const closePepsico = document.getElementById('closePepsico');
const closeCuetara = document.getElementById('closeCuetara');
const closeNissin = document.getElementById('closeNissin');
const closeAlpura = document.getElementById('closeAlpura');
const closeTamariz = document.getElementById('closeTamariz');
const closeLala = document.getElementById('closeLala');
const closeEmpacados = document.getElementById('closeEmpacados');
const closeSalchichoneria = document.getElementById('closeSalchichoneria');
const closeQualamex = document.getElementById('closeQualamex');

pronto.addEventListener('click', () => {
    popupPronto.classList.add('show');
});
selecta.addEventListener('click', () => {
    popupSelecta.classList.add('show');
});
maseca.addEventListener('click', () => {
    popupMaseca.classList.add('show');
});
pepsico.addEventListener('click', () => {
    popupPepsico.classList.add('show');
});
cuetara.addEventListener('click', () => {
    popupCuetara.classList.add('show');
});
nissin.addEventListener('click', () => {
    popupNissin.classList.add('show');
});
alpura.addEventListener('click', () => {
    popupAlpura.classList.add('show');
});
tamariz.addEventListener('click', () => {
    popupTamariz.classList.add('show');
});
lala.addEventListener('click', () => {
    popupLala.classList.add('show');
});
empacados.addEventListener('click', () => {
    popupEmpacados.classList.add('show');
});
salchichoneria.addEventListener('click', () => {
    popupSalchichoneria.classList.add('show');
});
qualamex.addEventListener('click', () => {
    popupQualamex.classList.add('show');
});


closePronto.addEventListener('click', () => {
    popupPronto.classList.remove('show');
});
closeSelecta.addEventListener('click', () => {
    popupSelecta.classList.remove('show');
});
closeMaseca.addEventListener('click', () => {
    popupMaseca.classList.remove('show');
});
closePepsico.addEventListener('click', () => {
    popupPepsico.classList.remove('show');
});
closeCuetara.addEventListener('click', () => {
    popupCuetara.classList.remove('show');
});
closeNissin.addEventListener('click', () => {
    popupNissin.classList.remove('show');
});
closeAlpura.addEventListener('click', () => {
    popupAlpura.classList.remove('show');
});
closeTamariz.addEventListener('click', () => {
    popupTamariz.classList.remove('show');
});
closeLala.addEventListener('click', () => {
    popupLala.classList.remove('show');
});
closeEmpacados.addEventListener('click', () => {
    popupEmpacados.classList.remove('show');
});
closeSalchichoneria.addEventListener('click', () => {
    popupSalchichoneria.classList.remove('show');
});
closeQualamex.addEventListener('click', () => {
    popupQualamex.classList.remove('show');
});