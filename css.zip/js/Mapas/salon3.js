const electrolit = document.getElementById('openElectrolit');
const jumex = document.getElementById('openJumex');
const pepsi = document.getElementById('openPepsi');
const cocacola = document.getElementById('openCocaCola');
const heineken = document.getElementById('openHeineken');
const copadeoro = document.getElementById('openCopaDeOro');
const elcompadre = document.getElementById('openElCompadre');
const licores = document.getElementById('openLicores');
const jaguar = document.getElementById('openJaguar');
const medicamentos = document.getElementById('openMedicamentos');
const pedigree = document.getElementById('openPedigree');
const kolaloka = document.getElementById('openKolaLoka');

const popupElectrolit = document.getElementById('popupElectrolit');
const popupJumex = document.getElementById('popupJumex');
const popupPepsi = document.getElementById('popupPepsi');
const popupCocacola = document.getElementById('popupCocacola');
const popupHeineken = document.getElementById('popupHeineken');
const popupCopaDeOro = document.getElementById('popupCopaDeOro');
const popupElCompadre = document.getElementById('popupElCompadre');
const popupLicores = document.getElementById('popupLicores');
const popupJaguar = document.getElementById('popupJaguar');
const popupMedicamentos = document.getElementById('popupMedicamentos');
const popupPedigree = document.getElementById('popupPedigree');
const popupKolaLoka = document.getElementById('popupKolaLoka');

const closeElectrolit = document.getElementById('closeElectrolit');
const closeJumex = document.getElementById('closeJumex');
const closePepsi = document.getElementById('closePepsi');
const closeCocacola = document.getElementById('closeCocacola');
const closeHeineken = document.getElementById('closeHeineken');
const closeCopaDeOro = document.getElementById('closeCopaDeOro');
const closeElCompadre = document.getElementById('closeElCompadre');
const closeLicores = document.getElementById('closeLicores');
const closeJaguar = document.getElementById('closeJaguar');
const closeMedicamentos = document.getElementById('closeMedicamentos');
const closePedigree = document.getElementById('closePedigree');
const closeKolaLoka = document.getElementById('closeKolaLoka');

electrolit.addEventListener('click', () => {
    popupElectrolit.classList.add('show');
});
jumex.addEventListener('click', () => {
    popupJumex.classList.add('show');
});
pepsi.addEventListener('click', () => {
    popupPepsi.classList.add('show');
});
cocacola.addEventListener('click', () => {
    popupCocacola.classList.add('show');
});
heineken.addEventListener('click', () => {
    popupHeineken.classList.add('show');
});
copadeoro.addEventListener('click', () => {
    popupCopaDeOro.classList.add('show');
});
elcompadre.addEventListener('click', () => {
    popupElCompadre.classList.add('show');
});
licores.addEventListener('click', () => {
    popupLicores.classList.add('show');
});
jaguar.addEventListener('click', () => {
    popupJaguar.classList.add('show');
});
medicamentos.addEventListener('click', () => {
    popupMedicamentos.classList.add('show');
});
pedigree.addEventListener('click', () => {
    popupPedigree.classList.add('show');
});
kolaloka.addEventListener('click', () => {
    popupKolaLoka.classList.add('show');
});


closeElectrolit.addEventListener('click', () => {
    popupElectrolit.classList.remove('show');
});
closeJumex.addEventListener('click', () => {
    popupJumex.classList.remove('show');
});
closePepsi.addEventListener('click', () => {
    popupPepsi.classList.remove('show');
});
closeCocacola.addEventListener('click', () => {
    popupCocacola.classList.remove('show');
});
closeHeineken.addEventListener('click', () => {
    popupHeineken.classList.remove('show');
});
closeCopaDeOro.addEventListener('click', () => {
    popupCopaDeOro.classList.remove('show');
});
closeElCompadre.addEventListener('click', () => {
    popupElCompadre.classList.remove('show');
});
closeLicores.addEventListener('click', () => {
    popupLicores.classList.remove('show');
});
closeJaguar.addEventListener('click', () => {
    popupJaguar.classList.remove('show');
});
closeMedicamentos.addEventListener('click', () => {
    popupMedicamentos.classList.remove('show');
});
closePedigree.addEventListener('click', () => {
    popupPedigree.classList.remove('show');
});
closeKolaLoka.addEventListener('click', () => {
    popupKolaLoka.classList.remove('show');
});