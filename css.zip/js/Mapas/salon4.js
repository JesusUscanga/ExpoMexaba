const jabonleon = document.getElementById('openJabonLeon');
const alen = document.getElementById('openAlen');
const colgate = document.getElementById('openColgate');
const clarasol = document.getElementById('openClarasol');
const lagloria = document.getElementById('openLaGloria');
const aramo = document.getElementById('openAramo');
const luzeterna = document.getElementById('openLuzEterna');
const lasoledad = document.getElementById('openLaSoledad');
const limabellota = document.getElementById('openLimaBellota');
const raid = document.getElementById('openRaid');
const procter = document.getElementById('openProcter');
const kimberly = document.getElementById('openKimberly');

const popupJabonLeon = document.getElementById('popupJabonLeon');
const popupAlen = document.getElementById('popupAlen');
const popupColgate = document.getElementById('popupColgate');
const popupClarasol = document.getElementById('popupClarasol');
const popupLaGloria = document.getElementById('popupLaGloria');
const popupAramo = document.getElementById('popupAramo');
const popupLuzEterna = document.getElementById('popupLuzEterna');
const popupLaSoledad = document.getElementById('popupLaSoledad');
const popupLimaBellota = document.getElementById('popupLimaBellota');
const popupRaid = document.getElementById('popupRaid');
const popupProcter = document.getElementById('popupProcter');
const popupKimberly = document.getElementById('popupKimberly');

const closeJabonLeon = document.getElementById('closeJabonLeon');
const closeAlen = document.getElementById('closeAlen');
const closeColgate = document.getElementById('closeColgate');
const closeClarasol = document.getElementById('closeClarasol');
const closeLaGloria = document.getElementById('closeLaGloria');
const closeAramo = document.getElementById('closeAramo');
const closeLuzEterna = document.getElementById('closeLuzEterna');
const closeLaSoledad = document.getElementById('closeLaSoledad');
const closeLimaBellota = document.getElementById('closeLimaBellota');
const closeRaid = document.getElementById('closeRaid');
const closeProcter = document.getElementById('closeProcter');
const closeKimberly = document.getElementById('closeKimberly');

jabonleon.addEventListener('click', () => {
    popupJabonLeon.classList.add('show');
});
alen.addEventListener('click', () => {
    popupAlen.classList.add('show');
});
colgate.addEventListener('click', () => {
    popupColgate.classList.add('show');
});
clarasol.addEventListener('click', () => {
    popupClarasol.classList.add('show');
});
lagloria.addEventListener('click', () => {
    popupLaGloria.classList.add('show');
});
aramo.addEventListener('click', () => {
    popupAramo.classList.add('show');
});
luzeterna.addEventListener('click', () => {
    popupLuzEterna.classList.add('show');
});
lasoledad.addEventListener('click', () => {
    popupLaSoledad.classList.add('show');
});
limabellota.addEventListener('click', () => {
    popupLimaBellota.classList.add('show');
});
raid.addEventListener('click', () => {
    popupRaid.classList.add('show');
});
procter.addEventListener('click', () => {
    popupProcter.classList.add('show');
});
kimberly.addEventListener('click', () => {
    popupKimberly.classList.add('show');
});


closeJabonLeon.addEventListener('click', () => {
    popupJabonLeon.classList.remove('show');
});
closeAlen.addEventListener('click', () => {
    popupAlen.classList.remove('show');
});
closeColgate.addEventListener('click', () => {
    popupColgate.classList.remove('show');
});
closeClarasol.addEventListener('click', () => {
    popupClarasol.classList.remove('show');
});
closeLaGloria.addEventListener('click', () => {
    popupLaGloria.classList.remove('show');
});
closeAramo.addEventListener('click', () => {
    popupAramo.classList.remove('show');
});
closeLuzEterna.addEventListener('click', () => {
    popupLuzEterna.classList.remove('show');
});
closeLaSoledad.addEventListener('click', () => {
    popupLaSoledad.classList.remove('show');
});
closeLimaBellota.addEventListener('click', () => {
    popupLimaBellota.classList.remove('show');
});
closeRaid.addEventListener('click', () => {
    popupRaid.classList.remove('show');
});
closeProcter.addEventListener('click', () => {
    popupProcter.classList.remove('show');
});
closeKimberly.addEventListener('click', () => {
    popupKimberly.classList.remove('show');
});